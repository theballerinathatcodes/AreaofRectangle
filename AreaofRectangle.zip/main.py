import math
width = int(input("Enter the width:"))
height = int(input("Enter the height"))
area = width * height
print("The area is", area, "square units.")